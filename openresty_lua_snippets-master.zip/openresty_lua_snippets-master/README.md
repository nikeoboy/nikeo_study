OpenResty Lua Snippets
=========

Powerful OpenResty develop plugin for sublime text 2/3

## Description

A quick-openresty develop plugin for sublime text 2/3.

##Features

 * create new project
 * user definition auto completion
 * system api completions support (lua 5.1)
 * some snippets,like if-else,if-elseif-else,while,comment,repeat-until....
 * create new lua file with template

## Installation

1.Install via [Package Control](https://sublime.wbond.net/)

2.Download .zip source file, then unzip it,rename it with "OpenResty",then clone "OpenResty" folder into the SublimeText ```Packages``` directory.  A restart of SublimeText might be nessecary to complete the install.


## Usage

### User definition auto completion

 right click "src" folder on the sidebar,select "Rebuild User Definition".
 and when you save a lua file in sublime,it will auto build all user definition in the current file.
 